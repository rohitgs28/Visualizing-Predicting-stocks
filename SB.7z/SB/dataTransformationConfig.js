function getTransformationJSONForSunburst() {
	return {
		"SunburstChart": {
			"ParentKey": "symbol",
			"open": {
				"UILabel": "OPEN"
			},
			"high": {
				"UILabel": "HIGH"
			},
			"low": {
				"UILabel": "LOW"
			},
			"close": {
				"UILabel": "CLOSE"
			}/* ,
			
			"adj_close": {
				"UILabel": "ADJ_CLOSE"
			} */

		}

	};
}
